SET statement_timeout = 3000000;

-- DEBUG LOCAL
UPDATE zsys_parametres_generaux SET valeur_page = '1' WHERE code_page = 'DEBUG_LOCAL';

-- Mise à zéro de l'automate, on met en immédiat chaque extra action au lieu d'une programmation
UPDATE extra_action SET idextra_methode = 1 WHERE 1=1;

-- annonymisation 
-- CONTACT
update contact set libelle = 'mmarie@assunie.fr' where idtype_contact = 3;
update contact set libelle = '06.32.46.93.59' where idtype_contact IN (1,2,4,5,6);

-- PERSONNE
update personne set nom = 'MARIE_' || idpersonne, prenom = 'Mathieu' where idpersonne > 5000000;
update personne set nom = 'MARIE_' || idpersonne, prenom = 'Mathieu' where idpersonne > 100000 and idpersonne < 900000;
update personne set nom = 'PARTENAIRE_' || idpersonne where idpersonne > 99 and idpersonne < 999;

-- AGENCE
update agence set email = 'mmarie@assunie.fr', telephone = '06.32.46.93.59',fax = '06.32.46.93.59', numero_orias = '1234', commentaire = 'Pas de commentaire' where 1=1;

-- GESTIONNAIRE
update gestionnaire set  email = 'mmarie@assunie.fr', telephone = '0632469359' where 1=1;
update gestionnaire set nom = 'AGENT_' || idgestionnaire where est_agent = true and est_partenaire = false;
update gestionnaire set nom = 'BACKOFFICE_' || idgestionnaire where est_membre_backoffice = true;
update gestionnaire set nom = 'PARTENAIRE_' || idgestionnaire where est_agent = false and est_partenaire = true;
update gestionnaire set nom = 'INFORMATICIEN_' || idgestionnaire where est_agent = false and est_partenaire = false and est_superviseur ;
update gestionnaire set motpasse = (select motpasse from gestionnaire where login = 'marmat') where 1=1 and login <> 'adminbdd';

-- CONDUCTEURS
update conducteur set ancien_assureur_nom = 'MACIF' , ancien_assureur_num_police = 'XXXYYYZZZ' where 1=1;

-- adresse agence
update adresse_agence set rue = '10 rue des bois' where 1=1;
 
-- adresse personne
update adresse_personne set rue = '15 Rue Carnot' where 1=1;

-- IBAN
update iban set iban = 'FR76XXXXXXXXXXXXXXX' , bic = 'BICXXXXXX', titulaire = 'DUGUDU Sahra', rib_compte = '00033052800' where 1=1;

-- immat
update risque_auto set immatriculation = 'EN-444-JL' where 1=1;
update risque_cyclo set immatriculation = 'EN-444-JL' where 1=1;
update risque_moto set immatriculation = 'EN-444-JL' where 1=1;
update risque_vsp set immatriculation = 'EN-444-JL' where 1=1;
update risque_tempo set immatriculation = 'EN-444-JL' where 1=1;